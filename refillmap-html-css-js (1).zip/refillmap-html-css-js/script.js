// RefillMap demo frontend: sample data only. Replace these entries with verified campus data.
const stations = [
  {id:1,name:'Library Ground Floor RO',building:'Library',buildingLabel:'Central Library',floor:'Ground Floor',type:'RO refill point',status:'working',temperature:'cold',distance:{'Library':40,'Academic Block A':260,'Student Centre':180,'Engineering Block':420,'Sports Complex':650,'Hostel Block 1':720},hours:'8:00 AM – 8:00 PM',lastChecked:'Today, 10:15 AM',details:'Near the main entrance, beside the help desk.'},
  {id:2,name:'Academic Block A Cooler',building:'Academic Block A',buildingLabel:'Academic Block A',floor:'1st Floor',type:'Water cooler',status:'working',temperature:'normal',distance:{'Library':260,'Academic Block A':35,'Student Centre':210,'Engineering Block':150,'Sports Complex':530,'Hostel Block 1':460},hours:'8:30 AM – 6:00 PM',lastChecked:'Today, 9:40 AM',details:'Opposite Room A-112, near the staircase.'},
  {id:3,name:'Student Centre Refill Point',building:'Student Centre',buildingLabel:'Student Centre',floor:'Ground Floor',type:'RO refill point',status:'working',temperature:'cold',distance:{'Library':180,'Academic Block A':210,'Student Centre':25,'Engineering Block':290,'Sports Complex':370,'Hostel Block 1':320},hours:'9:00 AM – 9:00 PM',lastChecked:'Today, 11:00 AM',details:'Beside the student activity notice board.'},
  {id:4,name:'Engineering Block RO',building:'Engineering Block',buildingLabel:'Engineering Block',floor:'2nd Floor',type:'RO refill point',status:'low',temperature:'normal',distance:{'Library':420,'Academic Block A':150,'Student Centre':290,'Engineering Block':55,'Sports Complex':470,'Hostel Block 1':390},hours:'8:00 AM – 6:30 PM',lastChecked:'Yesterday, 4:20 PM',details:'Outside the computer lab corridor. Water pressure reported low.'},
  {id:5,name:'Sports Complex Cooler',building:'Sports Complex',buildingLabel:'Sports Complex',floor:'Ground Floor',type:'Water cooler',status:'working',temperature:'cold',distance:{'Library':650,'Academic Block A':530,'Student Centre':370,'Engineering Block':470,'Sports Complex':30,'Hostel Block 1':410},hours:'6:00 AM – 8:00 PM',lastChecked:'Today, 7:30 AM',details:'Near the indoor court entrance.'},
  {id:6,name:'Hostel Block 1 RO',building:'Hostel Block 1',buildingLabel:'Hostel Block 1',floor:'Ground Floor',type:'RO refill point',status:'working',temperature:'normal',distance:{'Library':720,'Academic Block A':460,'Student Centre':320,'Engineering Block':390,'Sports Complex':410,'Hostel Block 1':45},hours:'24 hours',lastChecked:'Today, 8:00 AM',details:'Near the common room and reception.'},
  {id:7,name:'Library 2nd Floor Cooler',building:'Library',buildingLabel:'Central Library',floor:'2nd Floor',type:'Water cooler',status:'maintenance',temperature:'cold',distance:{'Library':95,'Academic Block A':300,'Student Centre':230,'Engineering Block':450,'Sports Complex':680,'Hostel Block 1':750},hours:'Library hours',lastChecked:'Yesterday, 2:15 PM',details:'Temporarily unavailable for filter maintenance.'},
  {id:8,name:'Academic Block A RO Annex',building:'Academic Block A',buildingLabel:'Academic Block A',floor:'Ground Floor',type:'RO refill point',status:'working',temperature:'cold',distance:{'Library':300,'Academic Block A':110,'Student Centre':190,'Engineering Block':190,'Sports Complex':560,'Hostel Block 1':490},hours:'8:30 AM – 6:00 PM',lastChecked:'Today, 9:15 AM',details:'Ground floor, beside the accessible entrance.'}
];

const $ = (selector) => document.querySelector(selector);
const stationGrid = $('#stationGrid');
const buildingSelect = $('#buildingSelect');
const searchInput = $('#searchInput');
const statusFilter = $('#statusFilter');
const tempFilter = $('#tempFilter');
const stationDialog = $('#stationDialog');
const reportDialog = $('#reportDialog');
let selectedStationId = null;
let toastTimer;

const statusText = {working:'Working', maintenance:'Under maintenance', low:'Low pressure'};
const statusClass = {working:'status-working', maintenance:'status-maintenance', low:'status-low'};
const temperatureText = {cold:'❄ Cold water', normal:'◉ Normal water'};
const distanceFrom = (station, building) => station.distance[building] ?? 9999;
const prettyDistance = (distance) => distance < 1000 ? `${distance} m` : `${(distance / 1000).toFixed(1)} km`;

function stationStatus(station) {
  return `<span class="status ${statusClass[station.status]}">● ${statusText[station.status]}</span>`;
}
function stationTemperature(station) {
  return `<span class="temp-badge">${temperatureText[station.temperature]}</span>`;
}
function stationCard(station) {
  return `<article class="station-card">
    <div class="station-card-top"><span class="station-icon">${station.type === 'RO refill point' ? '💧' : '🚰'}</span>${stationStatus(station)}</div>
    <h3>${station.name}</h3><p class="station-location">${station.buildingLabel} · ${station.floor}<br>${station.type}</p>
    <div class="badge-row">${stationTemperature(station)}</div>
    <div class="station-meta"><span class="distance">⌖ ${prettyDistance(distanceFrom(station, buildingSelect.value))} away</span><span class="last-checked" title="Last checked">✓ Listed</span></div>
    <div class="station-card-footer"><button class="details-btn" data-details="${station.id}">View details →</button><button class="report-small" data-report="${station.id}">Report issue</button></div>
  </article>`;
}

function getFilteredStations() {
  const query = searchInput.value.trim().toLowerCase();
  return stations.filter(station => {
    const matchesSearch = [station.name, station.buildingLabel, station.floor, station.type].some(value => value.toLowerCase().includes(query));
    const matchesStatus = statusFilter.value === 'all' || station.status === statusFilter.value;
    const matchesTemperature = tempFilter.value === 'all' || station.temperature === tempFilter.value;
    return matchesSearch && matchesStatus && matchesTemperature;
  }).sort((a,b) => {
    // Working stations appear first, followed by the closest options.
    const statusRank = {working:0,low:1,maintenance:2};
    return statusRank[a.status] - statusRank[b.status] || distanceFrom(a, buildingSelect.value) - distanceFrom(b, buildingSelect.value);
  });
}

function renderStations() {
  const filtered = getFilteredStations();
  stationGrid.innerHTML = filtered.map(stationCard).join('');
  $('#resultsCount').textContent = `${filtered.length} ${filtered.length === 1 ? 'location' : 'locations'}`;
  $('#emptyState').classList.toggle('hidden', filtered.length > 0);
  stationGrid.classList.toggle('hidden', filtered.length === 0);
  stationGrid.querySelectorAll('[data-details]').forEach(button => button.addEventListener('click', () => openStationDetails(Number(button.dataset.details))));
  stationGrid.querySelectorAll('[data-report]').forEach(button => button.addEventListener('click', () => openReport(Number(button.dataset.report))));
  $('#stationCount').textContent = stations.length;
  $('#workingCount').textContent = stations.filter(station => station.status === 'working').length;
  updateNearest();
}

function updateNearest() {
  const building = buildingSelect.value;
  const nearest = stations.filter(station => station.status === 'working').sort((a,b) => distanceFrom(a,building) - distanceFrom(b,building))[0];
  if (!nearest) return;
  selectedStationId = nearest.id;
  $('#nearestName').textContent = nearest.name;
  $('#nearestLocation').textContent = `${nearest.buildingLabel} · ${nearest.floor}`;
  $('#nearestDistance').textContent = prettyDistance(distanceFrom(nearest,building));
  $('#nearestResult .badge-row').innerHTML = `${stationStatus(nearest)}${stationTemperature(nearest)}`;
}

function openStationDetails(id) {
  const station = stations.find(item => item.id === id);
  if (!station) return;
  $('#stationDialogContent').innerHTML = `
    <div class="water-symbol">${station.type === 'RO refill point' ? '💧' : '🚰'}</div>
    <div class="eyebrow" style="margin-top:17px">STATION DETAILS</div><h2>${station.name}</h2>
    <div class="detail-location">${station.buildingLabel} · ${station.floor}</div>
    <div class="badge-row">${stationStatus(station)}${stationTemperature(station)}</div>
    <p>${station.details}</p>
    <div class="detail-row"><span>Distance from selected building</span><strong>${prettyDistance(distanceFrom(station,buildingSelect.value))}</strong></div>
    <div class="detail-row"><span>Opening hours</span><strong>${station.hours}</strong></div>
    <div class="detail-row"><span>Last checked</span><strong>${station.lastChecked}</strong></div>
    <div class="detail-actions"><button class="secondary-btn" id="detailsReportBtn">Report issue</button><button class="find-btn" id="detailsCloseBtn">Done ✓</button></div>`;
  stationDialog.showModal();
  $('#detailsCloseBtn').addEventListener('click', () => stationDialog.close());
  $('#detailsReportBtn').addEventListener('click', () => { stationDialog.close(); openReport(station.id); });
}

function openReport(id = null) {
  const select = $('#reportStation');
  select.innerHTML = stations.map(station => `<option value="${station.id}">${station.name} — ${station.buildingLabel}</option>`).join('');
  if (id !== null) select.value = String(id);
  $('#reportSuccess').classList.add('hidden');
  $('#reportForm').reset();
  if (id !== null) select.value = String(id);
  reportDialog.showModal();
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}

buildingSelect.addEventListener('change', renderStations);
searchInput.addEventListener('input', renderStations);
statusFilter.addEventListener('change', renderStations);
tempFilter.addEventListener('change', renderStations);
$('#findNearestBtn').addEventListener('click', () => {
  updateNearest();
  $('#nearestResult').scrollIntoView({behavior:'smooth',block:'center'});
  showToast('Nearest working station updated.');
});
$('#viewNearestBtn').addEventListener('click', () => openStationDetails(selectedStationId));
$('#topReportBtn').addEventListener('click', () => openReport());
$('#closeReportBtn').addEventListener('click', () => reportDialog.close());
$('#clearFiltersBtn').addEventListener('click', () => {
  searchInput.value = '';
  statusFilter.value = 'all';
  tempFilter.value = 'all';
  renderStations();
});
$('#reportForm').addEventListener('submit', event => {
  event.preventDefault();
  const reports = JSON.parse(localStorage.getItem('refillmapReports') || '[]');
  reports.push({stationId:Number($('#reportStation').value),issue:$('#issueType').value,details:$('#issueDetails').value.trim(),createdAt:new Date().toISOString()});
  localStorage.setItem('refillmapReports', JSON.stringify(reports));
  $('#reportSuccess').classList.remove('hidden');
  $('#issueDetails').value = '';
  showToast('Issue report saved on this device.');
});

renderStations();
